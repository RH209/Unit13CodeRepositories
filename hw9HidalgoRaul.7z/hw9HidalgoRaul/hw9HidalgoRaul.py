kmvalue = float(input("Enter the Distance in Kilometers : "))
mvalue = kmvalue * 0.621371
print("%.2f kilometers = %.2f miles " %(kmvalue,mvalue))